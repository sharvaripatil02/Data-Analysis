setwd("C:/Users/patil/Desktop/DATA ANALYSIS/participant_files")

#Copying files in separate dataset for processing
cancer.train_data <- read.csv(file = "training_data.csv", stringsAsFactors = FALSE, header = TRUE)
cancer.test_dataset <- read.csv(file = "Sharvari_score.csv", stringsAsFactors = FALSE, header = TRUE)

#Later used for splitting train and score dataset
cancer.train_data$TrainSet <- TRUE
cancer.test_dataset$TrainSet <- FALSE

#Combined train and score data set for cleaning & processing dataset
cancer.combined_set <- rbind(cancer.train_data, cancer.test_dataset)

#Cleaning of dataset - replacing NA's with median value of respective columns
gleason_score.median <- median(cancer.combined_set$gleason_score, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$gleason_score), "gleason_score"] <- gleason_score.median

age.median <- median(cancer.combined_set$age, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$age), "age"] <- age.median

race.median <- median(cancer.combined_set$race, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$race), "race"] <- race.median

height.median <- median(cancer.combined_set$height, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$height), "height"] <- height.median

weight.median <- median(cancer.combined_set$weight, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$weight), "weight"] <- weight.median

family_history.median <- median(cancer.combined_set$family_history, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$family_history), "family_history"] <- family_history.median

first_degree_history.median <- median(cancer.combined_set$family_history, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$first_degree_history), "first_degree_history"] <- first_degree_history.median

previous_cancer.median <- median(cancer.combined_set$previous_cancer, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$previous_cancer), "previous_cancer"] <- previous_cancer.median

smoker.median <- median(cancer.combined_set$smoker, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$smoker), "smoker"] <- smoker.median

tumor_diagnosis.median <- median(cancer.combined_set$tumor_diagnosis, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$tumor_diagnosis), "tumor_diagnosis"] <- tumor_diagnosis.median

tumor_6_months.median <- median(cancer.combined_set$tumor_6_months, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$tumor_6_months), "tumor_6_months"] <- tumor_6_months.median

tumor_1_year.median <- median(cancer.combined_set$tumor_1_year, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$tumor_1_year), "tumor_1_year"] <- tumor_1_year.median

psa_diagnosis.median <- median(cancer.combined_set$psa_diagnosis, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$psa_diagnosis), "psa_diagnosis"] <- psa_diagnosis.median

psa_6_months.median <- median(cancer.combined_set$psa_6_months, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$psa_6_months), "psa_6_months"] <- psa_6_months.median

psa_1_year.median <- median(cancer.combined_set$psa_1_year, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$psa_1_year), "psa_1_year"] <- psa_1_year.median

tea.median <- median(cancer.combined_set$tea, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$tea), "tea"] <- tea.median

survival_1_year.median <- median(cancer.combined_set$survival_1_year, na.rm = TRUE)
cancer.combined_set[is.na(cancer.combined_set$survival_1_year), "survival_1_year"] <- survival_1_year.median

#Calculating upper bound  & outlining it for filtering out 
upper <- boxplot.stats(cancer.combined_set$survival_7_years)$stats[5]
outlierfilter <- cancer.combined_set$survival_7_years < upper
cancer.combined_set[outlierfilter,]


survival.equation <- "survival_7_years ~ gleason_score + family_history + first_degree_history + previous_cancer + smoker + tumor_diagnosis + tumor_6_months + tumor_1_year + psa_diagnosis + psa_6_months + psa_1_year + symptoms + chm_thrpy + rad_rem + multi_thrpy + survival_1_year"

#Linear model for prediction of survival_7_years column values
survival.model <- lm(
  formula = survival.equation,
  data = cancer.combined_set[outlierfilter,]
)

survival7years.row <- cancer.combined_set[
is.na(cancer.combined_set$survival_7_years),
c("gleason_score", "family_history", "first_degree_history", "previous_cancer", "smoker", "tumor_diagnosis", "tumor_6_months", "tumor_1_year", "psa_diagnosis", "psa_6_months", "psa_1_year", "symptoms", "chm_thrpy", "rad_rem", "multi_thrpy", "survival_1_year")
]

#Predictions for values of survival_7_years
survival7years.predictions <- predict(survival.model, newdata = survival7years.row)

#Counting number of NA's in survival_7_years
cancer.combined_set[is.na(cancer.combined_set$survival_7_years), "survival_7_years"] <- survival7years.predictions

#Categorise casting
cancer.combined_set$side <- as.factor(cancer.combined_set$side)
cancer.combined_set$race <- as.factor(cancer.combined_set$race)
cancer.combined_set$symptoms <- as.factor(cancer.combined_set$symptoms)
cancer.combined_set$n_score <- as.factor(cancer.combined_set$n_score)

#Splitting train and score dataset from merged dataset/ combined dataset
cancer.train_data <- cancer.combined_set[cancer.combined_set$TrainSet==TRUE,]
cancer.test_dataset <- cancer.combined_set[cancer.combined_set$TrainSet==FALSE,]

#updating survival_7_years to their exact binary values using as.factor
cancer.train_data$survival_7_years <- as.factor(cancer.train_data$survival_7_years)

#RandomForest for regression testing
install.packages("randomForest")
library(randomForest)

survival.formula <- as.formula(survival.equation)

cancer.model <- randomForest(formula = survival.formula, data=cancer.train_data, ntree=500, mtry=3, nodesize = 0.01*nrow(cancer.test_dataset))

#Adding features to model
feature.equation <- "gleason_score + family_history + first_degree_history + previous_cancer + smoker + tumor_diagnosis + tumor_6_months + tumor_1_year + psa_diagnosis + psa_6_months + psa_1_year + symptoms + chm_thrpy + rad_rem + multi_thrpy + survival_1_year"

#Predicting survived cancer patients for 7 years based on model and equations
survived = predict(cancer.model, newdata = cancer.test_dataset)

patient.id <- cancer.test_dataset$id
output.df <- as.data.frame(patient.id)
output.df$survival_7_years <- survived
cancer.test_dataset$survival_7_years <- output.df$survival_7_years

#writing resultant output files to .csv format
write.csv(cancer.test_dataset, file="(Sharvari)_score.csv")
write.csv(cancer.train_data, file = "C:/Users/patil/Desktop/DATA ANALYSIS ENOVA/participant_files/train_dataset_cleaned.csv")
write.csv(cancer.test_dataset, file = "C:/Users/patil/Desktop/DATA ANALYSIS ENOVA/participant_files/test_dataset_cleaned.csv")

